#pragma once
#include <string>
#include <cstdlib>
#include <ctime>
#include <random>
#include <windows.h>


class Password
{

	private:
		int password_length;
		char pass_alphabet[80] = { 'A','B','C','D','E','F','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z', 'a','b','c','d','e','f','g','h','i','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z', '!','"','�','$','%','^','&','*','(',')','-','_',':',';','@','#','~',',','.' };
		std::string password;
		

	public:
		void set_plength(int p_length) { password_length = p_length; }
		int get_plength() { return password_length; }

		void set_password() { password = generatePassword(); }
		std::string get_pword() { return password; }
		void clear_password() { password.clear(); }

		
		std::string generatePassword() {

			std::string FinalPassword = "";
			std::string temp = "";

			srand((unsigned)time(0));

			temp.clear();
			FinalPassword.clear();

			
			int i;
			const int max = sizeof(pass_alphabet);
			int arr_val;

			Sleep(400);
			for (i = 0; i < password_length; i++) {

				
				arr_val = 0;

				arr_val = rand() % max;

				temp = temp + pass_alphabet[arr_val];

			
			}
			
			FinalPassword.append(temp);

			return FinalPassword;

		}


	

};

