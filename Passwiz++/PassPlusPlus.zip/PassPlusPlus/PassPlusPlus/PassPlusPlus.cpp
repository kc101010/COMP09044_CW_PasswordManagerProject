/*

	PASSWORD APPLICATION IN C++
	USES MULTITHREADING TO SPEED UP GENERATION PROCESS
	DOES NOT INVOLVE PASSWORD VALIDATION, PURELY GENERATION

	PASSWORD GENERATION SHOULD BE OBJECT ORIENTED, MUCH MORE EFFICIENT AND ALLOWS PRACTISE FOR OOP PROGRAMMING

	THREAD 1: USE RAND NUM GENERATOR TO CREATE PASSWORD
	THREAD 2: STORE PASSWORD TO FILE

 
	THREAD 1 GENERATE PASSWORD, PASS PASSWORD TO THREAD 2 WHICH STORES PASSWORD and repeat this process for each password
	This method could be more efficient and slightly quicker but harder to implement
	


	START MAIN~
	CHAR ARRAY ALPHABET

	REQUEST/STORE PASSWORD LENGTH (limit 16)
	REQUEST/STORE PASSWORD AMOUNT (limit 100 ~could change~)
	~END MAIN


*/

#include <iostream>
#include <thread>
#include <fstream>
#include <Windows.h>
#include "Password.h"





std::string generate(int temp_length) {
	Sleep(200);

	
	Password user_gen;
	Password* pword_ptr = &user_gen;


	user_gen.set_plength(temp_length);
	user_gen.clear_password();
	user_gen.set_password();

	std::cout << "Your password: " << pword_ptr->get_pword() << std::endl;

	std::string f_pasword = pword_ptr->get_pword();

	return f_pasword;
	
}

void write_file(int temp_length) {
	Sleep(200);
	std::ofstream password_file("passwords.txt", std::ios::app);

	try
	{
		password_file << generate(temp_length) << std::endl;
		//std::cout << "Success! Passwords saved to file" << std::endl;
		
	}
	catch (const std::exception&)
	{
		std::cout << "Error writing to file" << std::endl;
		std::cout << "Exiting program program..." << std::endl;
		exit(1);
		
	}

	password_file.close();
	
}

void pass_threading(int pass_amount, int temp_length) {

	for (int t = 0; t < pass_amount; t++) {
		//Sleep(100);
		std::thread gen_pass(generate, temp_length);
		gen_pass.join();

	}
	
	for (int y = 0; y < pass_amount / 2; y++) {
		//Sleep(100);
		std::thread write_pass(write_file, temp_length);
		write_pass.join();

	}
	
	
}

void getInput() {

	int pass_amount;
	int temp_length;

	do {
		std::cout << "Enter the amount of passwords to generate: " << std::endl;
		std::cin >> pass_amount;
	} while (pass_amount <= 0 || pass_amount > 25);

	do {
		std::cout << "Enter the length of your passwords" << std::endl;
		std::cin >> temp_length;
	} while (temp_length <= 0 || temp_length > 16);

	std::cout << "You will be creating " << pass_amount << " passwords. With a length of " << temp_length << std::endl;

	//generate(pass_amount, temp_length);
	pass_threading(pass_amount, temp_length);


}


int main() {

	getInput();
	
	return 0;
}











